use strict;

my $contigFile = shift @ARGV;
my $lowend = shift @ARGV;
my $highend = shift @ARGV;

open IN, "fastacat $contigFile |";

my $num = 1;

my $gce = "/home/troyce/work/HLAscripts/gce5";
#my $gce = "./gce5";

while (my $contig = <IN>)
{

	chomp $contig;

	if (length ($contig) >= $highend)
	{

		my $rc = reverse $contig;
		$rc =~ tr/ACGT/TGCA/;

		open OUT, ">$contigFile.primer";
		print OUT ">primer\n$contig";
		close OUT;

		my $threeprime = `$gce $contigFile.primer sorted.txt index.txt $lowend $highend 3 10 | cut -f 1 | tr -d '\n'`;

		open OUT, ">$contigFile.primer";
		print OUT ">primer\n$rc";
		close OUT;

		my $fiveprime = `$gce $contigFile.primer sorted.txt index.txt $lowend $highend 3 10 | cut -f 1 | tr -d '\n'`;

		$fiveprime = reverse $fiveprime;
		$fiveprime =~ tr/ACGT/TGCA/;

		$contig = $fiveprime . $contig . $threeprime;
		
	}

	print ">$num\n";

	while (length ($contig) > 60)
	{

		my $line = substr $contig, 0, 60, "";
		print "$line\n";

	}

	if (length ($contig) > 0)
	{

		print "$contig\n";

	}

	$num++;

}

close IN;

exit 0;
