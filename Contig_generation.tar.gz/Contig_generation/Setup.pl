use strict;

my $fq1 = shift @ARGV;
my $fq2 = shift @ARGV;

#`rm -Rf contigs.*`;

my $qsub = "qsub -b y -cwd -V -o /dev/null -e /dev/null";

#my $winID = `$qsub -N wdw 'perl ~/work/HLAscripts/GetWindow.pl $fq1 $fq2 > window.txt'`;
my $winID = `$qsub -N wdw 'echo "250,900" | tr "," "\t" > window.txt'`;
my $pfvID = `$qsub -N pfv 'perl ~/work/HLAscripts/PrepForVelvet.pl $fq1 $fq2 > forVelvet.txt'`;
my $gceID = `$qsub -N pgc 'perl ~/work/HLAscripts/PrepForGCE.pl $fq1 $fq2 > unsorted.txt'`;

$pfvID =~ /job [0-9]+/;
$pfvID = $&;
$pfvID =~ s/job //;

$gceID =~ /job [0-9]+/;
$gceID = $&;
$gceID =~ s/job //;

my $sortID = `$qsub -hold_jid $gceID -N sort '/bin/sort -T /home/troyce/tmp -S 2G unsorted.txt > sorted.txt'`;

$sortID =~ /job [0-9]+/;
$sortID = $&;
$sortID =~ s/job //;

my $indexID = `$qsub -hold_jid $sortID -N index 'cut -b 1-12 sorted.txt | uniqcnt > index.txt'`;

$indexID =~ /job [0-9]+/;
$indexID = $&;
$indexID =~ s/job //;

my $exhaustID = `$qsub -hold_jid $pfvID -N exhaust 'perl ~/work/HLAscripts/ExhaustAssemble.pl forVelvet.txt > velvet.log'`;

$exhaustID =~ /job [0-9]+/;
$exhaustID = $&;
$exhaustID =~ s/job //;

`$qsub -hold_jid $pfvID,$gceID,$sortID,$indexID,$exhaustID -N build 'perl ~/work/HLAscripts/RunAll.pl > runall.log'`;

exit 0;
