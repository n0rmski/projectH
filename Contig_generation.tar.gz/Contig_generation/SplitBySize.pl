use strict;

my $infile = shift @ARGV;
my $thresh = shift @ARGV;

open LONG, ">$infile.long";
open SHORT, ">$infile.short";

open IN, "fastacat $infile |";

my $longnum = 1;
my $shortnum = 1;

while (my $contig = <IN>)
{

	chomp $contig;

	if (length ($contig) < $thresh)
	{

		print SHORT ">$shortnum\n";
		while (length ($contig) > 60)
		{

			my $line = substr $contig, 0, 60, "";
			print SHORT "$line\n";

		}

		if (length ($contig) > 0)
		{

			print SHORT "$contig\n";

		}

		$shortnum++;

	}

	else
	{

		print LONG ">$longnum\n";
		while (length ($contig) > 60)
		{

			my $line = substr $contig, 0, 60, "";
			print LONG "$line\n";

		}

		if (length ($contig) > 0)
		{

			print LONG "$contig\n";

		}

		$longnum++;

	}

}

close IN;
close LONG;
close SHORT;

exit 0;
