use strict;

my $entryNum = 1;

my @trimmed;

foreach my $infile (@ARGV)
{

	open IN, "fastacat $infile |";

	while (my $entry = <IN>)
	{

		chomp $entry;

		if (length ($entry) <= 70)
		{

			next;

		}

		$entry =~ s/^[ACGT]{30}//;
		$entry =~ s/[ACGT]{30}$//;

		push @trimmed, $entry;

	}

	close IN;

}

my @splits = ();

foreach my $contig (@trimmed)
{

	$contig =~ s/A{10,}/AAAAAAAAAAHAAAAAAAAAA/g;

	my @s = split /H/, $contig;

	push @splits, @s;

}

@trimmed = @splits;

@splits = ();

foreach my $contig (@trimmed)
{

	$contig =~ s/T{10,}/TTTTTTTTTTHTTTTTTTTTT/g;

	my @s = split /H/, $contig;

	push @splits, @s;

}

@trimmed = @splits;

@splits = ();

foreach my $contig (@trimmed)
{

	my @s = split /(AC){10,}/, $contig;

	push @splits, @s;

}

@trimmed = @splits;

@splits = ();

foreach my $contig (@trimmed)
{

	my @s = split /(AG){10,}/, $contig;

	push @splits, @s;

}

@trimmed = @splits;

@splits = ();

foreach my $contig (@trimmed)
{

	my @s = split /(AT){10,}/, $contig;

	push @splits, @s;

}

@trimmed = @splits;

@splits = ();

foreach my $contig (@trimmed)
{

	my @s = split /(CG){10,}/, $contig;

	push @splits, @s;

}

@trimmed = @splits;

@splits = ();

foreach my $contig (@trimmed)
{

	my @s = split /(CT){10,}/, $contig;

	push @splits, @s;

}

@trimmed = @splits;

@splits = ();

foreach my $contig (@trimmed)
{

	my @s = split /(GT){10,}/, $contig;

	push @splits, @s;

}

@trimmed = @splits;

@splits = ();

foreach my $contig (@trimmed)
{

	#$contig =~ s/^[ACGT]{35}//;
	#$contig =~ s/[ACGT]{35}$//;

	push @splits, $contig;

}

@trimmed = @splits;

my $entryNum = 1;

foreach my $entry (@trimmed)
{

	if (length ($entry) < 101) { next; }

	print ">$entryNum\n";

	while (length ($entry) > 60)
	{

		my $line = substr $entry, 0, 60, "";
		print "$line\n";

	}

	if (length ($entry) > 0)
	{

		print "$entry\n";

	}

	$entryNum++;

}

exit 0;
