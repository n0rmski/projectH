use strict;

my $path = shift @ARGV;
my $barcode = shift @ARGV;

$path =~ s/\/+$//;

my @parts = split /\//, $path;

my $name = pop @parts;
$name .= "_$barcode";

if (! -e $name)
{

	`mkdir $name`;


}

my $qsub = "qsub -b y -cwd -V -o /dev/null -e /dev/null -N bcl2fq -p -1000";

my @filters = <$path/*.filter>;

foreach my $filter (@filters)
{

	my @parts = split /\//, $filter;

	my $tile = pop @parts;

	$tile =~ s/.filter$//;
	$tile =~ s/.*_//;

	my $r1 = "$name/$tile\_R1.fq";
	my $r2 = "$name/$tile\_R2.fq";

	`$qsub 'mono /bioinfoSD/troyce/work/bin/bcl2fq.exe -L $path -T $tile -barcode $barcode -bb 102 -be 107 -b 1 -e 101 > $r1; gzip $r1;'`;
	`$qsub 'mono /bioinfoSD/troyce/work/bin/bcl2fq.exe -L $path -T $tile -barcode $barcode -bb 102 -be 107 -b 109 -e 209 > $r2; gzip $r2;'`;

}

exit 0;
