use strict;

my $fq1 = shift @ARGV;
my $fq2 = shift @ARGV;
my $rate = shift @ARGV;

$rate += 0;

my $outfile1 = $fq1;
my $outfile2 = $fq2;

$outfile1 =~ s/\.fq$/_ds.fq/;
$outfile2 =~ s/\.fq$/_ds.fq/;

open FQ1, $fq1;
open FQ2, $fq2;

open OUT1, ">$outfile1";
open OUT2, ">$outfile2";

while ((my $a1 = <FQ1>) && (my $r1 = <FQ1>) && (my $b1 = <FQ1>) && (my $q1 = <FQ1>)
			&& (my $a2 = <FQ2>) && (my $r2 = <FQ2>) && (my $b2 = <FQ2>) && (my $q2 = <FQ2>))
{

	if (rand (1) > $rate) { next; }

	print OUT1 "$a1$r1$b1$q1";
	print OUT2 "$a2$r2$b2$q2";

}

close FQ1;
close FQ2;

close OUT1;
close OUT2;

exit 0;
