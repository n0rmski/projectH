use strict;

my $cur = 1;

while (my $row = <>)
{

	chomp $row;

	if ($row =~ />/)
	{

		print ">$cur\n";
		$cur++;

	}
	else
	{

		print "$row\n";

	}

}

exit 0;
