use strict;

open IN, "/home/troyce/work/HLAscripts/101mers.txt";

my %mers;

while (my $fwd = <IN>)
{

	chomp $fwd;

	my $rev = reverse $fwd;
	$rev =~ tr/ACGT/TGCA/;

	$mers {$fwd} = 1;
	$mers {$rev} = 1;

}

close IN;

my $fastq1 = shift @ARGV;
my $fastq2 = shift @ARGV;

open F1, $fastq1;
open F2, $fastq2;

while ((my $header1 = <F1>) && (my $read1 = <F1>) && (my $junk1 = <F1>) && (my $qual1 = <F1>)
			&& (my $header2 = <F2>) && (my $read2 = <F2>) && (my $junk2 = <F2>) && (my $qual2 = <F2>))
{

	chomp $header1;
	chomp $read1;
	chomp $junk1;
	chomp $qual1;

	chomp $header2;
	chomp $read2;
	chomp $junk2;
	chomp $qual2;

	if ($read1 =~ /A{85}/) { next; }
	if ($read1 =~ /T{85}/) { next; }

	if ($read2 =~ /A{85}/) { next; }
	if ($read2 =~ /T{85}/) { next; }

	if ($read1 =~ /N/) { next; }
	if ($read2 =~ /N/) { next; }

	if ($mers {$read1} == 1)
	{

		print "$read1\n$read2\n";

	}

	elsif ($mers {$read2} == 1)
	{

		print "$read1\n$read2\n";

	}

}

close F1;
close F2;

exit 0;
