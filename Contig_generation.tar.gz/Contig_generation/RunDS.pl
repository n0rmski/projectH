use strict;

my $qsub = "qsub -b y -cwd -V -o /dev/null -e /dev/null -N downsmpl";

open IN, "cat sizes.txt | gawk '\$1 = 167308332 / \$1' | tr ' ' '\t' | head -n 7 |";

while (my $row = <IN>)
{

	chomp $row;

	my ($rate, $r1) = split /\t/, $row;

	my $r2 = $r1;
	$r2 =~ s/R1/R2/;

	`$qsub 'perl Downsample.pl $r1 $r2 $rate'`;

}

exit 0;
