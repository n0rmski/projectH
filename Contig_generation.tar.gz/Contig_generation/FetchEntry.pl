use strict;

my $name = shift @ARGV;
my $infile = shift @ARGV;

$name = ">" . $name;

my $write = 0;

open IN, $infile;

while (my $row = <IN>)
{

	chomp $row;

	if ($row eq $name)
	{

		$write = 1;

	}

	elsif ($row =~ /^>/)
	{
	
		if ($write == 1)
		{

			exit 0;

		}

		$write = 0;

	}

	if ($write == 1)
	{

		print "$row\n";

	}

}

close IN;

exit 0;
