use strict;

my $fq1 = shift @ARGV;
my $fq2 = shift @ARGV;

my $readLength = -1;

if ($fq1 =~ /bz2$/)
{

	$readLength = `bzcat $fq1 | head -n 2 | tail -n 1 | gawk '{print length}'` + 0;
	`bzcat $fq1 | bowtie --quiet -q -v0 -m1 cox - | sed 's/\\s.*hap2//' | cut -f 1,2 | head -n 100000 | sort > 1.map`;
	`bzcat $fq2 | bowtie --quiet -q -v0 -m1 cox - | sed 's/\\s.*hap2//' | cut -f 1,2 | head -n 100000 | sort > 2.map`;

}

else
{

	$readLength = `cat $fq1 | head -n 2 | tail -n 1 | gawk '{print length}'` + 0;
	`cat $fq1 | bowtie --quiet -q -v0 -m1 cox - | sed 's/\\s.*hap2//' | cut -f 1,2 | head -n 100000 | sort > 1.map`;
	`cat $fq2 | bowtie --quiet -q -v0 -m1 cox - | sed 's/\\s.*hap2//' | cut -f 1,2 | head -n 100000 | sort > 2.map`;

}

open IN, "join 1.map 2.map | ";

my @lengths;

while (my $row = <IN>)
{

	chomp $row;

	my ($id, $one, $two) = split / /, $row;

	if ($one > $two)
	{

		my $tmp = $one;
		$one = $two;
		$two = $tmp;

	}

	my $tempLength = $two - $one + $readLength;

	push @lengths, $tempLength;

}

close IN;

`rm 1.map 2.map`;

my @sorted = sort {$a <=> $b} @lengths;

my $lower = $sorted[int (0.01 * @sorted)];
my $upper = $sorted[int (0.99 * @sorted)];

print "$lower\t$upper\n";

exit 0;
