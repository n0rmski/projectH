use strict;

`rm -Rf contigs.*`;

my $qsub = "qsub -b y -cwd -V -o /dev/null -e /dev/null";

my $lo = `head -n1 window.txt | cut -f 1` + 0;
my $hi = `head -n1 window.txt | cut -f 2` + 0;

my $k = `sort -k2,2nr -k3,3n -k1,1nr velvet.log | head -n 1 | cut -f 1` + 0;

`velveth velvet $k -raw -short forVelvet.txt`;
`velvetg velvet`;

`perl /home/troyce/work/HLAscripts/PolishVelvet.pl velvet/contigs.fa > contigs.fa`;
`perl /home/troyce/work/HLAscripts/SplitBySize.pl contigs.fa $hi`;
`cp /home/troyce/work/HLAscripts/AlignAll.pl .`;
`cp /home/troyce/work/HLAscripts/FetchEntry.pl .`;

my $alignID = `$qsub -N align 'perl /home/troyce/work/HLAscripts/AlignAll.pl /home/troyce/work/HLAscripts/known.fa contigs.fa.short contigs.fa.short.alignments'`;
$alignID =~ /job [0-9]+/;
$alignID = $&;
$alignID =~ s/job //;

my $aID = `$qsub -hold_jid $alignID -N extendS 'perl /home/troyce/work/HLAscripts/AidedExtend.pl contigs.fa.short.alignments known.fa contigs.fa.short $lo $hi > contigs.fa.short.extended'`;

my $bID = `$qsub -hold_jid $alignID -N extendS 'perl /home/troyce/work/HLAscripts/ExtractUnalignedShorts.pl contigs.fa.short contigs.fa.short.alignments > contigs.fa.short.unextended'`;

my $cID = `$qsub -N extendL 'perl /home/troyce/work/HLAscripts/Extend.pl contigs.fa.long $lo $hi > contigs.fa.long.extended'`;

$aID =~ /job [0-9]+/;
$aID = $&;
$aID =~ s/job //;

$bID =~ /job [0-9]+/;
$bID = $&;
$bID =~ s/job //;

$cID =~ /job [0-9]+/;
$cID = $&;
$cID =~ s/job //;

my $mergeID = `$qsub -N merge -hold_jid $aID,$bID,$cID 'cat contigs.fa.long.extended contigs.fa.short.extended contigs.fa.short.unextended | perl /home/troyce/work/HLAscripts/Renumber.pl > all.fa; toAmos -s all.fa -o all.afg;'`;

$mergeID =~ /job [0-9]+/;
$mergeID = $&;
$mergeID =~ s/job //;

my $assembleID = `$qsub -N minimus -hold_jid $mergeID 'minimus2 all -D OVERLAP=100 -D MINID=99 -D MAXTRIM=5; cat all.fasta all.singletons.seq | perl /home/troyce/work/HLAscripts/Renumber.pl > denovo.fa;'`;

$assembleID =~ /job [0-9]+/;
$assembleID = $&;
$assembleID =~ s/job //;

my $falignID = `$qsub -N align -hold_jid $assembleID 'perl AlignAll.pl /home/troyce/work/Fasta/chr6_cox_hap2.fa denovo.fa denovo.txt'`;

$falignID =~ /job [0-9]+/;
$falignID = $&;
$falignID =~ s/job //;

exit 0;
