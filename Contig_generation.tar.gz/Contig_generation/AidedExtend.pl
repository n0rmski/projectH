use strict;

my $alignFile = shift @ARGV;
my $targetFile = shift @ARGV;
my $contigFile = shift @ARGV;
my $lowend = shift @ARGV;
my $highend = shift @ARGV;

open IN, "grep S $alignFile | gawk '{print \$3, \$4, \$7, \$8, \$2}' |";

my $num = 1;

while (my $row = <IN>)
{

	chomp $row;

	my ($target, $size, $start, $stop, $id) = split / /, $row;

	my $contig = `perl FetchEntry.pl $id $contigFile | grep -v '>' | tr -d '\n'`;

	chomp $contig;

	my $base = `perl FetchEntry.pl $target $targetFile | grep -v '>' | tr -d '\n'`;

	chomp $base;

	my $orient = "F";

	if ($stop < $start)
	{
	
		$orient = "R";
		my $tmp = $start;
		$start = $stop;
		$stop = $tmp;
		$contig = reverse $contig;
		$contig =~ tr/ACGT/TGCA/;

	}

	my $orig = $contig;

	my $from = $start - $highend;

	my $pad = substr $base, $from, $highend;

	my $primer = $pad . $contig;

	open OUT, ">$alignFile.primer.fa";
	print OUT ">primer\n$primer";
	close OUT;

	my $new = `/home/troyce/work/HLAscripts/gce5 $alignFile.primer.fa sorted.txt index.txt $lowend $highend 3 10 | cut -f 1 | tr -d '\n'`;
	chomp $new;

	$contig .= $new;

	$pad = substr $base, $stop, $highend;

	$primer = $orig . $pad;
	
	$primer = reverse $primer;
	$primer =~ tr/ACGT/TGCA/;

	open OUT, ">$alignFile.primer.fa";
	print OUT ">primer\n$primer";
	close OUT;

	$new = `/home/troyce/work/HLAscripts/gce5 $alignFile.primer.fa sorted.txt index.txt $lowend $highend 3 10 | cut -f 1 | tr -d '\n'`;
	chomp $new;

	$new = reverse $new;
	$new =~ tr/ACGT/TGCA/;

	$contig = $new . $contig;

	my $after = length $contig;

	print ">$num\n";

	while (length ($contig) > 60)
	{

		my $line = substr $contig, 0, 60, "";
		print "$line\n";

	}

	if (length ($contig) > 0)
	{

		print "$contig\n";

	}

	$num++;

}

close IN;

exit 0;
