use strict;

my $infile = shift @ARGV;

open IN, "fastacat $infile |";

my $scafNum = 1;

while (my $seq = <IN>)
{

	chomp $seq;

	my @chunks = split /N+/, $seq;

	my $numChunks = @chunks;

	my $chunkNum = 1;

	foreach my $chunk (@chunks)
	{

		if (length ($chunk) == 0) { next; }

		$chunk = uc $chunk;

		#print ">$scafNum.$chunkNum\n";
		print ">$chunkNum\n";
		$chunkNum++;
		while (length ($chunk) > 60)
		{

			my $line = substr $chunk, 0, 60, "";
			print "$line\n";

		}

		if (length ($chunk) > 0)
		{

			print "$chunk\n";

		}

	}

	$scafNum++;

}

close IN;

exit 0;
