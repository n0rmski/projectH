use strict;

my $num = 1;

while (my $row = <>)
{

	chomp $row;

	print ">$num\n";

	while (length ($row) > 60)
	{

		my $line = substr $row, 0, 60, "";
		print "$line\n";

	}

	if (length ($row) > 0)
	{

		print "$row\n";

	}

	$num++;

}

exit 0;
