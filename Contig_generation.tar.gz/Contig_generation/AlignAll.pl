use strict;

my $db = shift @ARGV;
my $query = shift @ARGV;
my $out = shift @ARGV;	

if (-e $out)
{

	`rm $out`;

}

open IN, "grep '>' $query | tr -d '>' |";

while (my $row = <IN>)
{

	chomp $row;

	`perl /bioinfoSD/troyce/work/HLAscripts/FetchEntry.pl $row $query > $query.tmp`;

	my $n = `genomesize $query.tmp | cut -f 2` + 0;

	if ($n == 0)
	{

		#print "$row\n";
		exit 0;

	}

	if ($n >= 50)
	{

		`exonerate --dnawordlen 50 -n 1 -m affine:local -V 0 --showvulgar false --ryo "S\\t\%qi\\t\%ti\\t\%ql\\t\%qab\\t\%qae\\t\%tab\\t\%tae\\t\%V\\t\%ei\\t\%em\n" $query.tmp $db >> $out`;

	}
	else
	{

		`exonerate --dnawordlen $n -n 1 -m affine:local -V 0 --showvulgar false --ryo "S\\t\%qi\\t\%ti\\t\%ql\\t\%qab\\t\%qae\\t\%tab\\t\%tae\\t\%V\\t\%ei\\t\%em\n" $query.tmp $db >> $out`;

	}

	if (-e "$query.tmp")
	{

		`rm $query.tmp`;

	}

}

close IN;

exit 0;
