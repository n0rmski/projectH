#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int PosIntPower (int base, int exponent);
void LoadIndex (char* indexFile, char* indexedFile, unsigned long* offsets, int* counts, int hashSize);
unsigned int DnaToUint (char* dna, int n);
unsigned long GetLineSize (char* infile);
int GetReadLength (char* file);
int GetAllPairedReads (char* key, FILE* handle, unsigned long lineSize, int readLength,
											 unsigned long* offsets, unsigned int* counts, int hashSize,
											 int* numReads, char*** reads, unsigned char*** quals);
void ParseReads (char* buffer, int numClusters, int readLength, int lineSize,
								 char** read1, char** read2, char** qual1, char** qual2);
void MoveMatchesToFront (char* key, char** read1, char** read2, char** qual1, char** qual2,
												 int numCandidates, int* numMatches);
void SwapStrings (char** s1, char** s2);
void ReverseComplement (char* s, int n);
void ReverseString (char* s, int n);
int NumberOfBasesInFastaFile (char* contigFile);
void ReadFasta (char* contigFile, char* contig);
void FreeReadArray (char** r, int n);
void FreeQualArray (unsigned char** q, int n);
void InitQueues (char* primer, int primerLength, int longBound, int windowSize, int readLength,
								 char*** readQueue, unsigned char*** qualQueue, int* countQueue, FILE* handle,
								 unsigned long lineSize, unsigned long* offsets, unsigned int* counts, int hashSize);
void CountNextBase (char* contig, int contigSize, int windowSize, int* numA, int* numC, int* numG, int* numT,
										char*** readQueue, unsigned char*** qualQueue, int* countQueue, int readLength);
void IncrementCountsFromRead (char* read, unsigned char* qual, int* numA, int* numC, int* numG, int* numT,
															char* contig, int contigSize, int readLength);
void UpdateContig (char** contig, int* contigSize, int numA, int numC, int numG, int numT);
void UpdateQueues (char* contig, int contigSize, int longBound, int queueSize, int readLength,
									 char*** readQueue, unsigned char*** qualQueue, int* countQueue, FILE* handle,
									 unsigned long lineSize, unsigned long* offsets, unsigned int* counts, int hashSize);
int IsTailRepetitive (char* contig, int contigLength, int repLength);
int SanityCheck (int a, int c, int g, int t, int totalThresh, float relativeThresh);

int main (int argc, char** argv)
{

	char* primerFile = argv[1];
	char* readFile = argv[2];
	char* indexFile = argv[3];
	int loInsertSize = atoi (argv[4]); // sizes are low and high bound of fragment length distribution
	int hiInsertSize = atoi (argv[5]);
	int totalThresh = atoi (argv[6]);
	float relativeThresh = atof (argv[7]);
	
	char* contig;
	char* extendedContig;

	int contigSize = NumberOfBasesInFastaFile (primerFile);

	contig = (char*) malloc (sizeof (char) * contigSize);

	ReadFasta (primerFile, contig);

	int i;

	int hashSize = 12;

	int numBins = PosIntPower (4, hashSize);

	unsigned long* offsets = (unsigned long*) calloc (numBins, sizeof (unsigned long));
	unsigned int* counts = (unsigned int*) calloc (numBins, sizeof (unsigned int));

	int readLength = GetReadLength (readFile);
	unsigned long lineSize = GetLineSize (readFile);

	LoadIndex (indexFile, readFile, offsets, counts, hashSize);

	int numReads = -1;
	char** reads;
	unsigned char** quals;

	FILE* handle = fopen (readFile, "rb");

	int windowSize = hiInsertSize - loInsertSize + readLength;

	char*** readQueue = (char***) calloc (windowSize, sizeof (char**));
	unsigned char*** qualQueue = (unsigned char***) calloc (windowSize, sizeof (unsigned char**));
	int* countQueue = (int*) calloc (windowSize, sizeof (int));

	InitQueues (contig, contigSize, hiInsertSize, windowSize, readLength, readQueue, qualQueue, countQueue,
							handle, lineSize, offsets, counts, hashSize);

	int stillExtending = 1;

	int extensionLength = 0;

	while (stillExtending)
	{

		int numA = 0;
		int numC = 0;
		int numG = 0;
		int numT = 0;

		CountNextBase (contig, contigSize, windowSize, &numA, &numC, &numG, &numT,
									 readQueue, qualQueue, countQueue, readLength);

		if (numA + numC + numG + numT == 0)
			break;

		UpdateContig (&contig, &contigSize, numA, numC, numG, numT);

		UpdateQueues (contig, contigSize, hiInsertSize, windowSize, readLength, readQueue, qualQueue, countQueue,
									handle, lineSize, offsets, counts, hashSize);

		extensionLength++;

		stillExtending = IsTailRepetitive (contig, contigSize, readLength);

		stillExtending *= SanityCheck (numA, numC, numG, numT, totalThresh, relativeThresh);

		if (extensionLength > 2000000)
			stillExtending = 0;

		if (stillExtending)
			printf ("%c\t%d\t%d\t%d\t%d\n", contig[contigSize - 1], numA, numC, numG, numT);
	
		

	}

	for (i = 0; i < windowSize; i++)
	{

		FreeReadArray (readQueue[i], countQueue[i]);
		FreeQualArray (qualQueue[i], countQueue[i]);

	}

	fclose (handle);

	free (countQueue);
	free (readQueue);
	free (qualQueue);

	free (counts);
	free (offsets);
	free (contig);

	return EXIT_SUCCESS;

}

int SanityCheck (int a, int c, int g, int t, int totalThresh, float relativeThresh)
{

	int total = a + c + g + t;

	if (total < totalThresh)
		return 0;

	int* counts = (int*) malloc (sizeof (int) * 4);

	counts[0] = a;
	counts[1] = c;
	counts[2] = g;
	counts[3] = t;

	int i, j, key;

	for (j = 1; j < 4; j++)
	{
		key = counts[j];
		i = j - 1;
		while (i >= 0 && counts[i] > key)
		{
			counts[i+1] = counts[i];
			i--;
		}
		counts[i+1] = key;
	}

	total = counts[0] + counts[1] + counts[2];

	if (counts[3] < total * relativeThresh)
	{

		free (counts);
		return 0;

	}

	free (counts);
	
	return 1;

}

int IsTailRepetitive (char* contig, int contigLength, int repLength)
{

	char c = contig[contigLength - repLength];

	int i;

	for (i = contigLength - repLength + 1; i < contigLength; i++)
	{

		if (contig[i] != c)
			return 1;

	}

	return 0;

}


void UpdateQueues (char* contig, int contigSize, int longBound, int queueSize, int readLength,
									 char*** readQueue, unsigned char*** qualQueue, int* countQueue, FILE* handle,
									 unsigned long lineSize, unsigned long* offsets, unsigned int* counts, int hashSize)
{

	int i = -1;

	FreeReadArray (readQueue[0], countQueue[0]);
	FreeQualArray (qualQueue[0], countQueue[0]);

	for (i = 1; i < queueSize; i++)
	{

		readQueue[i - 1] = readQueue[i];
		qualQueue[i - 1] = qualQueue[i];
		countQueue[i - 1] = countQueue[i];

	}

	int pos = contigSize - longBound + queueSize - 2;

	char* key = (char*) malloc (sizeof (char) * (readLength + 1));

	strncpy (key, contig + pos, readLength);
	key[readLength] = '\0';

	int numReads;

	char** reads = NULL;
	unsigned char** quals = NULL;

	GetAllPairedReads (key, handle, lineSize, readLength, offsets, counts, hashSize, &numReads, &reads, &quals);

	readQueue[queueSize - 1] = reads;
	qualQueue[queueSize - 1] = quals;
	countQueue[queueSize - 1] = numReads;

	free (key);

}

void CountNextBase (char* contig, int contigSize, int windowSize, int* numA, int* numC, int* numG, int* numT,
										char*** readQueue, unsigned char*** qualQueue, int* countQueue, int readLength)
{

	int i = 0;
	int j = 0;

	*numA = 0;
	*numC = 0;
	*numG = 0;
	*numT = 0;

	for (i = 0; i < windowSize; i++)
	{

		for (j = 0; j < countQueue[i]; j++)
		{

			IncrementCountsFromRead (readQueue[i][j], qualQueue[i][j], numA, numC, numG, numT,
															 contig, contigSize, readLength);

		}

	}

}

void IncrementCountsFromRead (char* read, unsigned char* qual, int* numA, int* numC, int* numG, int* numT,
															char* contig, int contigSize, int readLength)
{


	int a = 0;
	int c = 0;
	int g = 0;
	int t = 0;

	int timesHit = 0;

	int k = 0;

	for (k = readLength - 1; k >= 20; k--)
	{

		if (strncmp (contig + contigSize - k, read, k) == 0 && qual[k] >= 30)
		{

			timesHit++;

			if (read[k] == 'A')
				a = 1;

			else if (read[k] == 'C')
				c = 1;

			else if (read[k] == 'G')
				g = 1;

			else if (read[k] == 'T')
				t = 1;

		}

	}

	if (timesHit == 1)
	{

		(*numA) += a;
		(*numC) += c;
		(*numG) += g;
		(*numT) += t;

	}

}

void InitQueues (char* primer, int primerLength, int longBound, int windowSize, int readLength,
								 char*** readQueue, unsigned char*** qualQueue, int* countQueue, FILE* handle,
								 unsigned long lineSize, unsigned long* offsets, unsigned int* counts, int hashSize)
{

	int pos;
	int queueIndex;

	char* key = (char*) malloc (sizeof (char) * (readLength + 1));

	char** reads = NULL;
	unsigned char** quals = NULL;
	
	queueIndex = 0;
	for (pos = primerLength - longBound; pos < primerLength - longBound + windowSize - 1; pos++)
	{

		strncpy (key, primer + pos, readLength);
		key[readLength] = '\0';

		int numReads;

		GetAllPairedReads (key, handle, lineSize, readLength, offsets, counts, hashSize, &numReads, &reads, &quals);

		readQueue[queueIndex] = reads;
		qualQueue[queueIndex] = quals;
		countQueue[queueIndex] = numReads;

		queueIndex++;

	}

	free (key);

}

void FreeQualArray (unsigned char** q, int n)
{

	if (n > 0)
	{

		int i;
		for (i = 0; i < n; i++)
			free (q[i]);

	}

	free (q);

}

void FreeReadArray (char** r, int n)
{

	if (n > 0)
	{

		int i;
		for (i = 0; i < n; i++)
			free (r[i]);

	}

	free (r);

}

void ReadFasta (char* contigFile, char* contig)
{

	FILE* f = fopen (contigFile, "r");

	char c;

	// Move past header line

	c = '\0';

	while (c != '\n')
		c = fgetc (f);

	int nucNum = 0;
	for (c = fgetc (f); c != EOF; c = fgetc (f))
	{

		if (c == '\n')
			continue;

		if (c == '\r')
			continue;

		if (c == 'a')
			c = 'A';

		if (c == 'c')
			c = 'C';

		if (c == 'g')
			c = 'G';

		if (c == 't')
			c = 'T';

		contig[nucNum] = c;

		nucNum++;

	}

	fclose (f);

}

int NumberOfBasesInFastaFile (char* contigFile)
{

	FILE* f = fopen (contigFile, "r");

	char c;

	// Move past header line

	c = '\0';

	while (c != '\n')
		c = fgetc (f);

	// Count nucleotides

	int numNucs = 0;
	for (c = fgetc (f); c != EOF; c = fgetc (f))
	{

		if (c == '\n')
			continue;

		if (c == '\r')
			continue;

		numNucs++;

	}

	fclose (f);

	return numNucs;

}

int GetAllPairedReads (char* key, FILE* handle, unsigned long lineSize, int readLength,
											 unsigned long* offsets, unsigned int* counts, int hashSize,
											 int* numReads, char*** reads, unsigned char*** quals)
{

	unsigned int index = DnaToUint (key, hashSize);

	unsigned int numCandidates = counts[index];

	if (numCandidates == 0)
	{

		*numReads = 0;
		*reads = NULL;
		*quals = NULL;
		return;

	}

	int bufferSize = numCandidates * lineSize + 1;

	char* buffer = (char*) malloc (sizeof (char) * bufferSize);

	unsigned long offset = offsets[index];

	fseek (handle, offset, SEEK_SET);

	fread (buffer, sizeof (char), bufferSize - 1, handle);

	buffer[bufferSize] = '\0';

	char** read1 = (char**) malloc (sizeof (char*) * numCandidates);
	char** read2 = (char**) malloc (sizeof (char*) * numCandidates);
	char** qual1 = (char**) malloc (sizeof (char*) * numCandidates);
	char** qual2 = (char**) malloc (sizeof (char*) * numCandidates);

	int clusterNum = -1;

	for (clusterNum = 0; clusterNum < numCandidates; clusterNum++)
	{

		read1[clusterNum] = (char*) malloc (sizeof (char) * (readLength + 1));
		read2[clusterNum] = (char*) malloc (sizeof (char) * (readLength + 1));
		qual1[clusterNum] = (char*) malloc (sizeof (char) * (readLength + 1));
		qual2[clusterNum] = (char*) malloc (sizeof (char) * (readLength + 1));

	}

	ParseReads (buffer, numCandidates, readLength, lineSize, read1, read2, qual1, qual2);
	
	int numMatches = 0;
	
	MoveMatchesToFront (key, read1, read2, qual1, qual2, numCandidates, &numMatches);

	if (numMatches == 0)
	{

		for (clusterNum = 0; clusterNum < numCandidates; clusterNum++)
		{

			free (read1[clusterNum]);
			free (read2[clusterNum]);
			free (qual1[clusterNum]);
			free (qual2[clusterNum]);

		}

		free (read1);
		free (read2);
		free (qual1);
		free (qual2);

		free (buffer);
		*numReads = 0;
		*reads = NULL;
		*quals = NULL;
		return;

	}

	int matchIndex;
	for (matchIndex = 0; matchIndex < numMatches; matchIndex++)
	{

		ReverseComplement (read2[matchIndex], readLength);
		ReverseString (qual2[matchIndex], readLength);

	}

	*reads = (char**) malloc (sizeof (char*) * numMatches);
	*quals = (unsigned char**) malloc (sizeof (char*) * numMatches);

	for (matchIndex = 0; matchIndex < numMatches; matchIndex++)
	{

		(*reads)[matchIndex] = (char*) malloc (sizeof (char) * (readLength + 1));
		(*quals)[matchIndex] = (unsigned char*) malloc (sizeof (unsigned char) * readLength);
		strcpy ((*reads)[matchIndex], read2[matchIndex]);
		strcpy ((*quals)[matchIndex], qual2[matchIndex]);

		int pos;

		for (pos = 0; pos < readLength; pos++)
			(*quals)[matchIndex][pos] -= 33;

	}

	for (clusterNum = 0; clusterNum < numCandidates; clusterNum++)
	{

		free (read1[clusterNum]);
		free (read2[clusterNum]);
		free (qual1[clusterNum]);
		free (qual2[clusterNum]);

	}

	free (read1);
	free (read2);
	free (qual1);
	free (qual2);

	free (buffer);

	*numReads = numMatches;

	return numMatches;

}

void ReverseString (char* s, int n)
{

	int i;
	char tmp;

	for (i = 0; i < (n + 1) / 2; i++)
	{

		tmp = s[i];
		s[i] = s[n - i - 1];
		s[n - i - 1] = tmp;

	}

}

void ReverseComplement (char* s, int n)
{

	int i;
	char tmp;

	for (i = 0; i < (n + 1) / 2; i++)
	{

		if (s[i] == 'A') tmp = 'T';
		else if (s[i] == 'C') tmp = 'G';
		else if (s[i] == 'G') tmp = 'C';
		else if (s[i] == 'T') tmp = 'A';

		if (s[n - i - 1] == 'A') s[i] = 'T';
		else if (s[n - i - 1] == 'C') s[i] = 'G';
		else if (s[n - i - 1] == 'G') s[i] = 'C';
		else if (s[n - i - 1] == 'T') s[i] = 'A';

		s[n - i - 1] = tmp;

	}

}

void MoveMatchesToFront (char* key, char** read1, char** read2, char** qual1, char** qual2,
												 int numCandidates, int* numMatches)
{

	int candidateNum = 0;
	int matchNum = 0;

	char* tmp;

	for (candidateNum = 0; candidateNum < numCandidates; candidateNum++)
	{

		if (strcmp (read1[candidateNum], key) == 0)
		{

			SwapStrings (read1 + matchNum, read1 + candidateNum);
			SwapStrings (read2 + matchNum, read2 + candidateNum);
			SwapStrings (qual1 + matchNum, qual1 + candidateNum);
			SwapStrings (qual2 + matchNum, qual2 + candidateNum);

			matchNum++;

		}

	}

	*numMatches = matchNum;

}

void SwapStrings (char** s1, char** s2)
{

	char* tmp = "\0";
	tmp = *s1;
	*s1 = *s2;
	*s2 = tmp;
	
}

void ParseReads (char* buffer, int numClusters, int readLength, int lineSize,
								 char** read1, char** read2, char** qual1, char** qual2)
{

	int clusterNum;

	for (clusterNum = 0; clusterNum < numClusters; clusterNum++)
	{

		strncpy (read1[clusterNum], buffer + clusterNum * lineSize, readLength);
		strncpy (read2[clusterNum], buffer + clusterNum * lineSize + readLength + 1, readLength);
		strncpy (qual1[clusterNum], buffer + clusterNum * lineSize + 2 * (readLength + 1), readLength);
		strncpy (qual2[clusterNum], buffer + clusterNum * lineSize + 3 * (readLength + 1), readLength);

		read1[clusterNum][readLength] = '\0';
		read2[clusterNum][readLength] = '\0';
		qual1[clusterNum][readLength] = '\0';
		qual2[clusterNum][readLength] = '\0';

	}

}

int GetReadLength (char* file)
{

	FILE* f = fopen (file, "r");

	char* buffer = (char*) malloc (sizeof (char) * 1024);

	fgets (buffer, 1024, f);

	int length = strlen (strtok (buffer, "\t"));
	
	fclose (f);

	free (buffer);

	return length;

}

unsigned int DnaToUint (char* dna, int n)
{

	int i;

	int pow4 = 1;

	unsigned int sm = 0;

	for (i = n - 1; i >= 0; i--)
	{

		if (dna[i] == 'C')
			sm += pow4 * 1;
		else if (dna[i] == 'G')
			sm += pow4 * 2;
		else if (dna[i] == 'T')
			sm += pow4 * 3;

		pow4 *= 4;

	}

	return sm;

}

unsigned long GetLineSize (char* infile)
{

	char* buffer = (char*) malloc (sizeof (char) * 65536);
	FILE* f = fopen (infile, "r");
	fgets (buffer, 65536, f);
	fclose (f);
	unsigned long lineSize = (unsigned long) strlen (buffer);
	free (buffer);
	
	return lineSize;

}

void LoadIndex (char* indexFile, char* indexedFile, unsigned long* offsets, int* counts, int hashSize)
{

	char* buffer = (char*) malloc (sizeof (char) * 65536);

	FILE* indexed = fopen (indexedFile, "r");
	fgets (buffer, 65536, indexed);
	fclose (indexed);
	unsigned long lineSize = (unsigned long) strlen (buffer);

	FILE* f = fopen (indexFile, "r");

	unsigned int bin;
	unsigned int count;
	unsigned long numLines = 0;

	while (fgets (buffer, 65536, f) != NULL)
	{

		bin = DnaToUint (buffer, hashSize);
		offsets[bin] = numLines * lineSize;
		strtok (buffer, "\t");
		count = (unsigned int) atoi (strtok (NULL, "\t"));
		numLines += count;
		counts[bin] = count;

	}

	free (buffer);

	fclose (f);

}

int PosIntPower (int base, int exponent)
{

	int i;
	int power = 1;

	for (i = 0; i < exponent; i++)
		power *= base;

	return power;

}

void UpdateContig (char** contig, int* contigSize, int numA, int numC, int numG, int numT)
{

	char c = 'N';

	if (numA > numC && numA > numG && numA > numT)
		c = 'A';

	else if (numC > numA && numC > numG && numC > numT)
		c = 'C';

	else if (numG > numA && numG > numC && numG > numT)
		c = 'G';

	else if (numT > numA && numT > numC && numT > numG)
		c = 'T';

	else if (numA == numC && numA > numG && numA > numT)
		c = (rand() % 2 == 0) ? 'A' : 'C';

	else if (numA == numG && numA > numC && numA > numT)
		c = (rand() % 2 == 0) ? 'A' : 'G';

	else if (numA == numT && numA > numC && numA > numG)
		c = (rand() % 2 == 0) ? 'A' : 'T';

	else if (numC == numG && numC > numA && numC > numT)
		c = (rand() % 2 == 0) ? 'C' : 'G';

	else if (numC == numT && numC > numA && numC > numG)
		c = (rand() % 2 == 0) ? 'C' : 'T';

	else if (numG == numT && numG > numA && numG > numC)
		c = (rand() % 2 == 0) ? 'G' : 'T';

	else if (numA == numC && numA == numG && numA > numT)
	{

		int r = rand () % 3;

		if (r == 0) c = 'A';
		else if (r == 1) c = 'C';
		else if (r == 2) c = 'G';

	}

	else if (numA == numC && numA == numT && numA > numG)
	{

		int r = rand () % 3;

		if (r == 0) c = 'A';
		else if (r == 1) c = 'C';
		else if (r == 2) c = 'T';

	}

	else if (numA == numG && numA == numT && numA > numC)
	{

		int r = rand () % 3;

		if (r == 0) c = 'A';
		else if (r == 1) c = 'G';
		else if (r == 2) c = 'T';

	}

	else if (numC == numG && numC == numT && numC > numA)
	{

		int r = rand () % 3;

		if (r == 0) c = 'C';
		else if (r == 1) c = 'G';
		else if (r == 2) c = 'T';

	}

	else if (numA == numC && numA == numG && numA == numT && numA > 0)
	{

		int r = rand () % 4;

		if (r == 0) c = 'A';
		else if (r == 1) c = 'C';
		else if (r == 2) c = 'G';
		else if (r == 3) c = 'T';

	}
	
	// Update contig
	char* extendedContig = (char*) malloc (sizeof (char) * (*contigSize + 1));
	strncpy (extendedContig, *contig, *contigSize);
	extendedContig[*contigSize] = c;
	(*contigSize)++;
	free (*contig);
	*contig = (char*) malloc (sizeof (char) * (*contigSize));
	strncpy (*contig, extendedContig, *contigSize);
	free (extendedContig);

}
