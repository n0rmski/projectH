use strict;

`cat R1.fq | bowtie --quiet -v0 -m1 hg19 - | cut -f 1,2,3,4 | head -n 100000 > R1.align`;
`cat R2.fq | bowtie --quiet -v0 -m1 hg19 - | cut -f 1,2,3,4 | head -n 100000 > R2.align`;

my $target = "~/work/ForSteve/dunn.bed";
my $total = `wc -l R1.align` + 0;
my $ontarget = `cat R1.align | gawk '{print \$3,\$4,\$4 + 101}' | tr ' ' '\\t' | intersectBed -a stdin -b $target | wc -l` + 0;

`cat R1.fq | bowtie --quiet -v0 -M1 cox - | cut -f 1,2,3,4 | sed 's/chr6.*\t/chr6\t/' > R1.align`;
`cat R2.fq | bowtie --quiet -v0 -M1 cox - | cut -f 1,2,3,4 | sed 's/chr6.*\t/chr6\t/' > R2.align`;

`cat R1.align R2.align | gawk '{print \$3,\$4,\$4 + 101}' | tr ' ' '\\t' | coverageBed -d -a stdin -b ~/work/ForSteve/hla.bed | cut -f 5 > depth.txt`;

my $mean = `rowmean depth.txt` + 0;
my $p20 = `cat depth.txt | gawk '{print \$1 >= 0.20 * $mean}' | rowmean` + 0;
my $p10 = `cat depth.txt | gawk '{print \$1 >= 0.10 * $mean}' | rowmean` + 0;
my $p01 = `cat depth.txt | gawk '{print \$1 >= 0.01 * $mean}' | rowmean` + 0;
my $p00 = `cat depth.txt | gawk '{print (\$1 > 0)}' | rowmean` + 0;

my $enrich = sprintf "%0.4f", $ontarget / $total;
my $mean = sprintf "%0.4f", $mean;
my $p20 = sprintf "%0.4f", $p20;
my $p10 = sprintf "%0.4f", $p10;
my $p01 = sprintf "%0.4f", $p01;
my $p00 = sprintf "%0.4f", $p00;

print "ENRICH:\t$enrich\n";
print "MEAN:\t$mean\n";
print "COV:\t$p00\n";
print "P01:\t$p01\n";
print "P10:\t$p10\n";
print "P20:\t$p20\n";

exit 0;
