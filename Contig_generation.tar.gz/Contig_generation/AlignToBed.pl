use strict;

my $infile = shift @ARGV;

open IN, "grep S $infile |";

while (my $row = <IN>)
{

	chomp $row;

	my @a = split /\t/, $row;

	my $start = $a[6];
	my $stop = $a[7];

	if ($stop < $start)
	{

		my $tmp = $start;
		$start = $stop;
		$stop = $tmp;

	}

	print "chr6_cox_hap2\t$start\t$stop\n";

}

close IN;

exit 0;
