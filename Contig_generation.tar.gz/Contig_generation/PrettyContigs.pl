use strict;

my $infile = shift @ARGV;

open IN, "fastacat $infile |";

my $entryNum = 1;

while (my $entry = <IN>)
{

	chomp $entry;

	if (length ($entry) == 0)
	{

		next;

	}

	print ">$entryNum\n";

	while (length ($entry) > 60)
	{

		my $line = substr $entry, 0, 60, "";
		print "$line\n";

	}

	if (length ($entry) > 0)
	{

		print "$entry\n";

	}

	$entryNum++;

}

close IN;

exit 0;
