use strict;

my $infile = shift @ARGV;

open IN, "fastacat $infile |";

while (my $scaf = <IN>)
{

	chomp $scaf;

	$scaf = uc $scaf;

	my @ns = split /[ACGT]+/, $scaf;

	foreach my $nstring (@ns)
	{

		my $n = length $nstring;

		if ($n == 0) { next; }

		print "$n\n";

	}

}

close IN;

exit 0;
