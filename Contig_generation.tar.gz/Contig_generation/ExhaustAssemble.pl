use strict;

$|= 1;

my $infile = shift @ARGV;

`velveth local 99 -raw -short $infile`;

for (my $k = 51; $k <= 99; $k+=2)
{

	`velveth local $k -reuse_Sequences`;

	`velvetg local`;

	my $score = `fastacat local/contigs.fa | gawk 'length >= 1000 {print length}' | rowsum` + 0;
	my $numC = `grep -c '>' local/contigs.fa` + 0;
	my $total = `fastacat local/contigs.fa | gawk '{print length}' | rowsum` + 0;

	print "$k\t$score\t$numC\t$total\n";

}

exit 0;
