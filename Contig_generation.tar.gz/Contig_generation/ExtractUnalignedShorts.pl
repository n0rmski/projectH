use strict;

my $fasta = shift @ARGV;
my $alignment = shift @ARGV;

my @entries = `fastacat $fasta`;
my @aligned = `grep S $alignment | cut -f 2`;

my %extended;

foreach my $a (@aligned)
{

	$a += 0;
	$extended {$a} = 1;

}

my $num = 1;

for (my $i = 1; $i < @entries + 1; $i++)
{

	if (!defined $extended {$i})
	{

		my $contig = $entries[$i-1];
		chomp $contig;

		print ">$num\n";

		while (length ($contig) > 60)
		{

			my $line = substr $contig, 0, 60, "";
			print "$line\n";

		}

		if (length ($contig) > 0)
		{

			print "$contig\n";

		}

		$num++;

	}

}

exit 0;
