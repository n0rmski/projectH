use strict;

my $alignSize = `grep S denovo.txt | tr ' ' '_' | perl /home/troyce/work/HLAscripts/AlignToBed.pl | sort -k2,2n | mergeBed -i stdin | gawk '{print \$3 - \$2}' | rowsum` + 0;

#my $targetSize = `fastacat sanger.fa | gawk '{print length}' | rowsum` + 0;
my $targetSize = `fastacat /home/troyce/work/Fasta/chr6_cox_hap2.fa | gawk '{print length}' | rowsum` + 0;

my $pctCovered = $alignSize / $targetSize;

my $subs = `grep S denovo.txt | tr ' ' '_' | gawk '\$11 / (\$10 + \$11) < 0.02 {print \$11}' | rowsum` + 0;
my $ident = `grep S denovo.txt | tr ' ' '_' | gawk '\$11 / (\$10 + \$11) < 0.02 {print \$10}' | rowsum` + 0;

my $indels = `grep S denovo.txt | tr ' ' '_' | gawk '\$11 / (\$10 + \$11) < 0.02' | fold -w 1 | grep -c G` + 0;

my $subRate = $subs / ($subs + $ident);
my $indelRate = $indels / ($ident + $subs);

print "COVERAGE\t$pctCovered\n";
print "SUBRATE\t$subRate\n";
print "INDRATE\t$indelRate\n";

my @dstats = `getN50 denovo.fa`;

foreach my $stat (@dstats)
{

	chomp $stat;
	$stat =~ tr/ /\t/;
	print "DENOVO_$stat\n";

}

#my @bstats = `getN50 boosted.fa`;

#foreach my $stat (@bstats)
#{

#	chomp $stat;
#	$stat =~ tr/ /\t/;
#	print "FULL_$stat\n";

#}

exit 0;
